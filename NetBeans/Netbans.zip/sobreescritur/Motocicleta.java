/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sobreescritur;

/**
 *
 * @author Constanza
 */
public class Motocicleta extends Vehiculo{
    @Override
    public void mover(){
        System.out.println("El movimiento de una motocicleta es sobre dos ruedas, con un motor que funciona con gasolina");
    }
    
}
