/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sobreescritur;

/**
 *
 * @author Constanza
 */
public class Bicicleta extends Vehiculo{
    @Override
    public void mover(){
        System.out.println("El movimiento de una bicicleta es sobre dos ruedas, y avanza con la accion de pedalear");
    
    }
    
}
